﻿using FileProcessing.Models;
using Microsoft.EntityFrameworkCore;
using System.Xml.Linq;

namespace FileProcessing.Services
{
    public class FileProcessRepo:IFileProcessRepo
    {
        private readonly Context cntx;
        public FileProcessRepo(Context cntx)
        {
            this.cntx = cntx;
        }

        public async Task<FileUploadResult> ProcessFileAsync(IFormFile file)
        {
            var result = new FileUploadResult();

            try
            {
                if (file.ContentType == "text/csv")
                {
                    await ProcessCsvAsync(file, result);
                }
                else if (file.ContentType == "application/xml")
                {
                    await ProcessXmlAsync(file, result);
                }
                else
                {
                    result.ErrorDetails = "Invalid file format. Only CSV and XML are supported.";
                }
            }
            catch (Exception ex)
            {
                result.ErrorDetails = $"Error processing file: {ex.Message}";
            }

            return result;
        }

        private async Task ProcessCsvAsync(IFormFile file, FileUploadResult result)
        {
            using var stream = new StreamReader(file.OpenReadStream());
            string? line;
            while ((line = await stream.ReadLineAsync()) != null)
            {
                var columns = line.Split(',');
                if (columns.Length == 2 && ValidateData(columns[0], columns[1]))
                {
                    cntx.ProcessedData.Add(new ProcessedData
                    {
                        DataField1 = columns[0],
                        DataField2 = columns[1]
                    });
                    result.ValidRows++;
                }
                else
                {
                    result.InvalidRows++;
                }

                result.TotalRows++;
            }

            await cntx.SaveChangesAsync();
        }

        private async Task ProcessXmlAsync(IFormFile file, FileUploadResult result)
        {
            try
            {
                var document = XDocument.Load(file.OpenReadStream());
                foreach (var element in document.Descendants("Record"))
                {
                    var field1 = element.Element("Field1")?.Value;
                    var field2 = element.Element("Field2")?.Value;

                    if (ValidateData(field1, field2))
                    {
                        cntx.ProcessedData.Add(new ProcessedData
                        {
                            DataField1 = field1,
                            DataField2 = field2
                        });
                        result.ValidRows++;
                    }
                    else
                    {
                        result.InvalidRows++;
                    }

                    result.TotalRows++;
                }

                await cntx.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                result.ErrorDetails = $"XML parsing error: {ex.Message}";
            }
        }

        private bool ValidateData(string? field1, string? field2)
        {
            return !string.IsNullOrWhiteSpace(field1) && !string.IsNullOrWhiteSpace(field2);
        }
    }
}
