﻿using FileProcessing.Models;

namespace FileProcessing.Services
{
    public interface IFileProcessRepo
    {
        Task<FileUploadResult> ProcessFileAsync(IFormFile file);
    }
}
