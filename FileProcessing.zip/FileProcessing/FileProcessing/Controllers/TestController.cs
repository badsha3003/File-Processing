﻿using FileProcessing.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FileProcessing.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        private readonly IFileProcessRepo _frepo;
        public TestController(IFileProcessRepo frepo)
        {
            _frepo = frepo; 
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("File is required.");
            }

            // Log file details
            Console.WriteLine($"Uploaded file ContentType: {file.ContentType}");
            Console.WriteLine($"Uploaded file Name: {file.FileName}");
            Console.WriteLine($"Uploaded file Length: {file.Length}");

            // Check ContentType and fallback to file extension
            var fileName = file.FileName.ToLower();
            if ((file.ContentType != "text/csv" && file.ContentType != "application/xml" && file.ContentType != "text/xml") &&
                !(fileName.EndsWith(".csv") || fileName.EndsWith(".xml")))
            {
                return BadRequest("Invalid file format. Only CSV and XML files are supported.");
            }

            // Log to verify file content
            using (var reader = new StreamReader(file.OpenReadStream()))
            {
                Console.WriteLine($"File content preview: {await reader.ReadLineAsync()}");
            }

            var result = await _frepo.ProcessFileAsync(file);
            return Ok(result);
        }
    }
}
