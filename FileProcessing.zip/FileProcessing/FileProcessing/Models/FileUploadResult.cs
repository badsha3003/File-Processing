﻿namespace FileProcessing.Models
{
    public class FileUploadResult
    {
        public int TotalRows { get; set; }
        public int ValidRows { get; set; }
        public int InvalidRows { get; set; }
        public string ErrorDetails { get; set; } = string.Empty;
    }
}
